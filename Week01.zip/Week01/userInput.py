userAge = int(input("Enter your age:"))
userAge = userAge + 22
print("Now showing the shop items filtred by age: ", userAge)